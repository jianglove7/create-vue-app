import axios from 'axios';

let urls = {
  login: {
    mock: 'static/api/login.json',
    server: ''
  }
};

if (process.env.NODE_ENV === 'production') {
  for (let url in Object.keys(urls)) {

  }
} else {
  for (let api in Object.keys(api)) {

  }
}

export default urls;