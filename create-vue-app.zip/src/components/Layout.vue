<template>
    <div>
        <keep-alive>
            <router-view class="page-content" v-if="$route.meta.keepAlive"></router-view>
        </keep-alive>
        <router-view class="page-content" v-if="!$route.meta.keepAlive"></router-view>
    </div>
</template>

<script>
export default {
        
};
</script>

<style lang="scss" scoped>

</style>