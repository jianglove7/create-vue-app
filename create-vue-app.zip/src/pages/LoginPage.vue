<template>
  <div id="LoginPage">
    <div class="login_hd">
      登陆
    </div>
    <div class="login_bd">
      <form action="" method="post">
        <div class="row">
          <label for="username"></label>
          <input type="text" name="username" v-model="userName" @keyup="handleKeyUp(event)">
        </div>
        <div class="row">
          <label for="password"></label>
          <input type="text" name="password" v-model="userName" @keyup="handleKeyUp(event)">
        </div>
        <div class="row">
          <button>登陆</button>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      form: {
        userName: '',
        passWord: ''
      }
    };
  },
  mounted() {

  },
  methods: {
    handleKeyUp(event) {
      console.log(event);
    }
  }
};

</script>

<style lang="scss" scoped>

</style>
